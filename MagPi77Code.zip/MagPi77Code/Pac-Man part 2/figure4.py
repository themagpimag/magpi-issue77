# This code is in the update() function

        for g in range(len(ghosts)):
            if ghosts[g].status > 0: ghosts[g].status -= 1
            if ghosts[g].collidepoint((player.x, player.y)):
                if ghosts[g].status > 0:
                    player.score += 100
                    animate(ghosts[g], pos=(290, 370), duration=1/SPEED, tween='linear', on_finished=flagMoveGhosts)
                else:
                    player.lives -= 1
                    if player.lives == 0:
                        player.status = 3
                    else:
                        player.status = 1
    
